from django.shortcuts import render, HttpResponse
import requests
import json
from Search.TFIDF.invertedIndex import InvertedIndex
from Search.TFIDF.utilities import _safe_print

II = InvertedIndex()
II.initializeIndex()
oldSearchString = ""

# Create your views here.
def Search(request):
    global II
    global oldSearchString
    
    searchData = {}

    new_domain = request.POST.get('add_domain')
    feedback = request.GET.get('feedback')
    searchString = request.GET.get('search')

    
    if feedback:
        print("\n" + "".join(["=" for x in range(28+len(feedback))]))
        print("======== FEEDBACK: " + feedback + " ========")
        print("".join(["=" for x in range(28+len(feedback))]) + "\n")
        
        searchString = oldSearchString
        searchData = II.relevenceFeedback(feedback)
        
    elif searchString:
        print("\n" + "".join(["=" for x in range(32+len(searchString))]))
        print("======== SEARCH QUERY: " + searchString + " ========")
        print("".join(["=" for x in range(32+len(searchString))]) + "\n")
        
        oldSearchString = searchString
        searchData = II.search(searchString)
        
    else:
        searchString = ""
        
    if new_domain:
        print("Coming soon")
        print("Adding domain: " + new_domain)
        
    return render(request, 'Search/search.html', {'data':sorted(searchData.items()), 'searchString': searchString})
    