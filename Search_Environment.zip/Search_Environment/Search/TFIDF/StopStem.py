from stop_words import get_stop_words
from stemming.porter2 import stem
#from nltk import PorterStemmer
import re

stop_words = get_stop_words('en')

def stripPunct(word):
    # remove punctuation after the word
    m = re.match("(.*)[!?,.;:)('\"]+", word)
    if m:
        word = m.group(1)
        
    # remove punctuation before the word
    m = re.match("[!?,.;:)('\"]+(.*)", word)
    if m:
        word = m.group(1)
        
    return word

            
def removeStopWords(wordlist):
    # remove stop words
    return [x for x in wordlist if x not in stop_words]
  
  
def stemWords(wordlist):
    # stem words in wordlist
    return [stem(x) for x in wordlist]
    

def sanitizeWordlist(wordlist):
    # convert all words to lowercase and strip punctuation
    wordlist = [stripPunct(x.lower()) for x in wordlist]
    
    # remove stop words from wordlist
    wordlist = removeStopWords(wordlist)
    
    # stem words
    wordlist = stemWords(wordlist)
    
    # convert all 4-digt numbers with trailing text to just 4-digit numbers
    for (i, word) in enumerate(wordlist):
        m = re.match("(\d+).*", word)
        if m:
            #if not m.group(0).endswith("th"):
            wordlist[i] = m.group(1)
    
    # remove all single-character words ~~and all number-only "words"~~:
    wordlist = [x for x in wordlist if (len(x) > 1)]# and not x.isdigit())]
    
    return wordlist
