# library functions
from os import listdir
from os.path import isfile, join
import math
import pickle
from itertools import product

# custom functions
from .StopStem import sanitizeWordlist
from .utilities import _safe_print
from .utilities import MyHTMLParser as HTMLParser

import codecs
#logfile = codecs.open("log.txt", "w", encoding="utf-8")

class InvertedIndex:
    def __init__(self):
        self.feedbackweight = {"alpha": 0.7, "beta": 0.3, "gamma": 0}
        self.documentCount = 0
        self.invertedIndex = {}
        self.documentList = []
        self.documentTitles = {}
        self.documentVectors = {}
        self.termLocations = {}
        self.query = {"string": "", "wordlist": [], "vector": {}, "candidatepool": set()}
        
    # build the inverted index from files found in sourcedir
    def generateIndex(self, sourcedir="./source"):
        from_path = sourcedir#"./source"
        '''to_path = "./parsed"'''
        for file in listdir(from_path):
            filepath = join(from_path, file)
            
            # check the extension to only include htm and txt documents
            if isfile(filepath) and (file[-3:] in ["htm", "txt"]):
                try:
                    print("Working on " + file)
                except:
                    _safe_print("Working on " + file)
                print("   Stripping html...")
                
                parsedFile = HTMLParser(open(filepath, 'rt', encoding='latin1').read())
                
                self.documentTitles[file] = parsedFile.title
                
                _safe_print(file + " - " + self.documentTitles[file])
                
                wordlist = parsedFile.wordlist()
                
                print("   Removing stop words then stemming...")
                wordlist = sanitizeWordlist(wordlist) # stemming, stop words, punctuation removal
                
                # write wordlist parsed version of file to ./parsed/
                '''print("   Writing wordlist to file...")
                outfile = open(join(to_path, file), 'w')
                for word in wordlist:
                    outfile.write(word + "\n")
                outfile.close()'''
                
                
                print("   Updating invertedIndex")
                
                self.documentCount += 1
                self.documentList.append(file)
                
                DF_updated = {}
                for i, word in enumerate(wordlist):
                    if file not in self.termLocations:
                        self.termLocations[file] = {}
                    
                    if word not in self.termLocations[file]:
                        self.termLocations[file][word] = []
                        
                    self.termLocations[file][word].append(i)
                    
                    # add word to inverted index if it isn't already
                    if word not in self.invertedIndex:
                                               #TF, #DF, posting list
                        #invertedIndex[word] = [0, 0, {}]
                        self.invertedIndex[word] = {"TF": 0, "DF": 0, "PostingList": {}}
                        
                    # add file to inverted index listing for the current word if it isn't already
                    #if file not in invertedIndex[word][2]:
                    #    invertedIndex[word][2][file] = 0
                    if file not in self.invertedIndex[word]["PostingList"]:
                        self.invertedIndex[word]["PostingList"][file] = 0
                        
                    # update the term frequency count for the current word overall
                    #invertedIndex[word][0] += 1
                    self.invertedIndex[word]["TF"] += 1
                    
                    # update document frequency count for the current word
                    if word not in DF_updated:
                        # set the current word as update for the current document
                        DF_updated[word] = 1
                        # update DF
                        #invertedIndex[word][1] += 1
                        self.invertedIndex[word]["DF"] += 1
                    
                    # update the posting list & term frequency count for the current word in the specific document
                    #invertedIndex[word][2][file] += 1
                    self.invertedIndex[word]["PostingList"][file] += 1
                    
                    
        return

    # for each document in the document list compute its weight vector
    def populateDocumentVectors(self):
        print("Computing document weight vectors")
        for document in self.documentList:
            self.documentVectors[document] = self.getDocumentVector(document)
    
    # Compute a weight vector for the file specified by filename
    def getDocumentVector(self, filename):
        # 'filename' is a sting containing the filename

        # initialize the vector to 0
        weights = {}
        
        # iterate over each of the words in the index in alphabetical order
        if filename in self.termLocations:
            for word in self.termLocations[filename]:
                weights[word] = self.invertedIndex[word]["PostingList"][filename] * math.log10(self.documentCount / self.invertedIndex[word]["DF"])
                
        return weights
        
    # sanitize query and turn it into a bag of words (wordlist)
    def processQuery(self):
        # 'query' is a string
        
        self.query["wordlist"] = [x for x in self.query["string"].split()]
        self.query["wordlist"] = sanitizeWordlist(self.query["wordlist"])
    
    # compute weight vector of query (as wordlist)
    def getQueryVector(self):
        # 'query' is a bag of words (list object)
        
        # convert bag of words to dictionary
        termFrequencyDict = {}
        for word in self.query["wordlist"]:
            if word not in termFrequencyDict:
                termFrequencyDict[word] = 1
            else:
                termFrequencyDict[word] += 1
        
        self.query["vector"] = {}    
        # compute TF-IDF for each term
        for word in set(self.query["wordlist"]):
            if word in self.invertedIndex:
                self.query["vector"][word] = termFrequencyDict[word] * math.log10(self.documentCount / self.invertedIndex[word]["DF"])
            
    # figure out which documents contain terms present in the query
    def setCandidatePool(self):
        self.query["candidatepool"] = set()
        for term in self.query["wordlist"]: 
            if term in self.invertedIndex:
                for document in self.invertedIndex[term]["PostingList"]:
                    self.query["candidatepool"].add(document)
                
    # compute similarity list
    def computeSearchSimilaritiesList(self):
        
        # for every document in the candidate pool, add its similarity score to the list
        similaritiesList = {}
        for document in self.query["candidatepool"]:
            similaritiesList[document] = self.cosSim(self.query["vector"], self.documentVectors[document])
            
        if similaritiesList != {}:
            tempmax = max(similaritiesList.values())
        else:
            tempmax = 0
        
        if tempmax != 0:
            for document in self.query["candidatepool"]:
                similaritiesList[document] = similaritiesList[document] / tempmax
            
        return similaritiesList
    
    # sort similarity results and store result in dictionary
    def searchRankResults(self, similaritiesScores, proximitiesScores):
        overallscores = []
        for document in self.query["candidatepool"]:
            cos_weight = 9/10
            prox_weight = 1-cos_weight
            score = cos_weight * similaritiesScores[document] + prox_weight * proximitiesScores[document]
            overallscores.append((score, document))
        
        sortedResults = {}
        for (i, result) in enumerate(sorted(overallscores, key=lambda x: x[0], reverse=True)):
            sortedResults[i] = {}
            sortedResults[i]["name"] = result[1]
            sortedResults[i]["title"] = self.documentTitles[result[1]]
            sortedResults[i]["sim"] = round(similaritiesScores[result[1]],5)
            sortedResults[i]["prox"] = round(proximitiesScores[result[1]],5)
            sortedResults[i]["net"] = round(result[0], 5)
            
        return sortedResults
    
    # write the index to a human-readable file
    def writeInvertedIndex2File(self, filename):
        print("Writing inverted index to file '" + filename + "'.")
        # write inverted Index to file
        II = open(join("./", filename), 'w', encoding='utf8')
        for word in sorted(self.invertedIndex.keys()):
            II.write(word + " -- " + str(self.invertedIndex[word]) + "\n")
        II.close()

    # compute the cosine similarity between two vectors
    def cosSim(self, queryVect, documentVect):
        queryL = self.vectorLength(queryVect)
        if (queryL != 0):
            documentL = self.vectorLength(documentVect)
            return self.vectorDot(queryVect, documentVect) / (queryL * documentL)
        else:
            return 0
            
    def vectorLength(self, vector):
        sum = 0
        for key in vector:
            #print(key)
            sum += math.pow(vector[key], 2)
            
        return math.sqrt(sum)
        
    def vectorDot(self, vec1, vec2):
        sum = 0
        for term in vec1:
            if term in vec2:
                sum += vec1[term] * vec2[term] 
                
        return sum
        
    # should move this to __init__ eventually
    # figure out if the source dir has been indexed yet and fix if it hasn't
    def initializeIndex(self, dir="./static/searchfiles"):
        if len(self.invertedIndex) == 0: # Do we need to build an index?
            loadFromFile = False
            if isfile("indexDump.bin"): # Does a binary dump exist?
                '''loadCheck = input("File 'indexDump.bin' found.  " + \
                    "Would you like to load the index from this file (y or n)? ")
                
                    # loadCheck set to automatically load from index dump
                '''
                loadCheck = "y"
                if loadCheck.lower()[0] != "n": # Does the user want to use the binary dump?
                    print("Loading index from file...")
                    self.loadIndex("indexDump.bin")
                else:
                    loadFromFile = True
            if not isfile("indexDump.bin") or loadFromFile: # if a binary dump doesn't exist
                print("Indexing files...")
                self.generateIndex(dir)
                #self.writeInvertedIndex2File("InvertedIndex.txt")
                self.populateDocumentVectors()
                self.dumpIndex("indexDump.bin")
        elif len(self.documentVectors) == 0: # do we need to compute documet vectors?
            self.populateDocumentVectors()
            self.dumpIndex("indexDump.bin")

    def computeProximityScoreList(self):
        proximities = {}
        scores = {}
        max_sum = -1
        
        # find the minimum distance between term pairs for each document and sum between pairs of terms
        for document in self.query["candidatepool"]:
            sum = 0
            
            for i in range(0, len(self.query["wordlist"])-1):
                term1 = self.query["wordlist"][i]
                term2 = self.query["wordlist"][i+1]
                
                min_dist = -1
                
                if term1 in self.termLocations[document] and term2 in self.termLocations[document]:
                    for (i1, i2) in product(self.termLocations[document][term1], self.termLocations[document][term2]):
                        if min_dist != -1:
                            min_dist = min(abs(i1-i2), min_dist)
                        else:
                            min_dist = abs(i1-i2)
                    
                if min_dist > -1:
                    sum += min_dist
                    
            if max_sum != -1:
                max_sum = max(sum, max_sum)
            else:
                max_sum = sum
                
            proximities[document] = sum
            
        
        # compute scores from proximity sums
        for document in self.query["candidatepool"]:
            if proximities[document] != 0:
                scores[document] = math.log10(max_sum/proximities[document])
            else:
                scores[document] = 0
                
        # scale scores
        if scores != {}:
            tempmax = max(scores.values())
        else:
            tempmax = 0
        if tempmax != 0:
            for document in self.query["candidatepool"]:
                scores[document] = scores[document] / tempmax
                
        '''
        for document in self.query["candidatepool"]:
            _safe_print(document[:30].ljust(30) + "\t" + str(proximities[document]) + "\t" + str(format(scores[document], '.4f')))
        '''
        
        return scores
    
    # gets the similarity list then sorts the list into a dictionary
    def search(self, queryString, dir="./source"):
        self.query["string"] = queryString
        self.processQuery()
        self.getQueryVector()
        
        self.setCandidatePool()
        
        similaritiesList = self.computeSearchSimilaritiesList()
        proximitiesList = self.computeProximityScoreList()
        
        if similaritiesList or proximitiesList:
            return self.searchRankResults(similaritiesList, proximitiesList)
        else:
            return {"No results found": ""}
        
    def relevenceFeedback(self, document):
        for term in self.documentVectors[document]:
            if term not in self.query["vector"]:
                self.query["vector"][term] = self.feedbackweight["beta"] * self.documentVectors[document][term]
            else:
                self.query["vector"][term] = self.feedbackweight["alpha"] * self.query["vector"][term]
                self.query["vector"][term] += self.feedbackweight["beta"] * self.documentVectors[document][term]
                
        similaritiesList = self.computeSearchSimilaritiesList()
        proximitiesList = self.computeProximityScoreList()
        
        if similaritiesList or proximitiesList:
            return self.searchRankResults(similaritiesList, proximitiesList)
        else:
            return {"No results found": ""}
    
    
    def dumpIndex(self, filename):
        with open(filename, 'wb') as dumpFile:
            pickle.dump((self.documentCount, self.invertedIndex, self.documentList, self.documentVectors, self.documentTitles, self.termLocations), dumpFile)
                
    def loadIndex(self, filename):
        if isfile(filename):
            with open(filename, 'rb') as dumpFile:
                (self.documentCount, self.invertedIndex, self.documentList, self.documentVectors, self.documentTitles, self.termLocations) = pickle.loads(dumpFile.read())
        else:
            print("Sorry, '" + filename + "' doesn't exist.")
            
            
            
if __name__ == "__main__":
    print("\nThis is for debugging purposes\n\n")
    from runner import printSearchResults
    
    i = InvertedIndex()
    i.initializeIndex()
    i.computeProximityScoreList()

    