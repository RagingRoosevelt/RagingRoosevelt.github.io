# Python version check
import os.path
from sys import version_info
if version_info < (3,4):
    print("\n\nWARNING: You need to use python version 3.4 or newer.\n\n")
    quit()

# Check for required packages
from pip import get_installed_distributions
# build list of installed packages
installed_packages = [package.project_name for package in get_installed_distributions()]
# list of required_packages
required_packages = ["stop-words", "stemming", "beautifulsoup4"]#, "Django"]
# check if each required package is installed
for package in required_packages:
    if package not in installed_packages:
        print("\n\nWARNING: You need to have the '" + package + "' package installed.  Try running:")
        print("\tpip install " + package)
        print("from a privileged terminal")
        quit()
    
# import invertedIndex class
from invertedIndex import InvertedIndex
from utilities import _safe_print

def printSearchResults(searchResults):
    print("\n----+-----Search Results-----------")
    print(  "  r | sim     | document")
    print(  "----+---------+--------------------")
    for key in sorted(searchResults, key=lambda x: int(x)):
        tempstr = str(key).rjust(3) 
        tempstr += " | {0:.5f}".format(searchResults[key]["sim"]) 
        tempstr += " | " + searchResults[key]["title"]
        # tempstr += " | " + searchResults[key]["name"]
        _safe_print(tempstr)

if __name__ == "__main__":
    index = InvertedIndex()
    '''
    loadFromFile = False
    if os.path.isfile("indexDump.bin"):
        loadCheck = input("File 'indexDump.bin' found.  " + \
            "Would you like to load the index from this file (y or n)? ")
            
        if loadCheck.lower()[0] != "n":
            print("Loading index from file...")
            index.loadIndex("indexDump.bin")
        else:
            loadFromFile = True
    if not os.path.isfile("indexDump.bin") or loadFromFile:
        print("Indexing files...")
        index.generateIndex("./source")
        index.writeInvertedIndex2File("InvertedIndex.txt")
        index.populateDocumentVectors()
        
        index.dumpIndex("indexDump.bin")
    '''
    
    index.initializeIndex()
    
    while True:
        # get a query from the user
        query = input("\n\nWhat would you like to search for? ")
        print("Searching for '" + query + "'...")
        
        # compute the similarities
        searchResults = index.search(query)
        
        # print the similarity results
        printSearchResults(searchResults)
            
        if (input("\n\nWould you like to search again (y or n)? ").lower()[0] == "n"):
            break
        