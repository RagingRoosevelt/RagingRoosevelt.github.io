from urllib.request import urlopen, urlretrieve
from urllib.parse import urljoin, urlparse, urlunparse
from os.path import join, isdir
from os import makedirs
from datetime import datetime
#from bs4 import BeautifulSoup
from queue import Queue
import re
from utilities import _safe_print
from utilities import MyHTMLParser as HTMLParser

class Crawler:
    def __init__(self, seedURL):
        self.TLDs = (".com", ".org", ".net", "int", ".edu", ".gov", ".mil", ".io", ".co.uk", ".me")
        self.queue = Queue()
        self.queue.put(seedURL)
        
        self.URLfrontier = Queue()
        
        self.currentCrawlCount = 0
        self.currentCrawlDepth = 0
        
        self.targetCrawlCount = -1
        self.targetCrawlDepth = -1
        self.targetDomain = ""
        
        self.seen = {}
        
    def download(self, url, output_path="./searchfiles"):
        try:
            pageHTML = urlopen(url)
        except:# HTTPError as e:
            #print(e)
            return None
        
        if pageHTML is None:
            print("warning: URL '" + url + "' not found")
            return None
        else:
            if not isdir(output_path):
                makedirs(output_path)
                
        
            pageObj = HTMLParser(str(pageHTML.read()))
            pageHTML.close()
            
            title = str(pageObj.title)
            #title = re.sub('<[^>]*>', '', title)
            #print(title)
            
            text = str(pageObj.text())
            
            #path = str(url[8:])
            #print(path)
            #filename = str(title[:150] + ".htm")
            filename = datetime.now().strftime("%Y%m%d%H%M%S") + ".htm"
            badchars = ["<", ">", ":", "/", "\\", "|", "?", "*", "\n", "\t", "\r", "\"", "%"]
            filename = "".join([c for c in filename if c not in badchars])
            
            
            urlretrieve(url, join(output_path, filename))
            #outputFile = open(join(output_path, filename), 'w', encoding='utf8')
            #outputFile.write(str(urlopen(url).read()))
            #outputFile.close()
            
            return pageObj
        
    def crawlNextPage(self):
        if not (self.currentCrawlCount < self.targetCrawlCount) and self.targetCrawlCount != -1:
            self.queue = Queue()
            self.URLfrontier = Queue()
            return
        else:
            url = self.queue.get()
            if url.endswith(self.TLDs):
                url += "/"
            self.seen[url] = 1
                    
            pageObj = self.download(url)
            
            if pageObj is not None:
                self.currentCrawlCount += 1
            
                print("    Processing page #" + str(self.currentCrawlCount) + " at depth " + str(self.currentCrawlDepth) + " with URL '" + url[:100] + "'")
            
                pageLinks = [urljoin(url, x) for x in pageObj.links]
                
                for link in pageLinks:
                    u = urlparse(link)
                    u = urlunparse((u.scheme, u.netloc, u.path, "", "", "")) # strip anchors, etc
                    
                    correct_format = not u.endswith(("pdf", "jpg", "png", "gif", "vcf"))
                    correct_domain = self.targetDomain in u
                    link_not_seen = u not in self.seen
                    if correct_format and link_not_seen and correct_domain:
                        self.URLfrontier.put(u)
                        self.seen[u] = 1
                
                self.queue.task_done()
        
    def crawlNextLevel(self):
        
        if not (self.currentCrawlDepth <= self.targetCrawlDepth) and self.targetCrawlDepth != -1:
            self.queue = Queue()
            self.URLfrontier = Queue()
            return
        else:
            if self.queue.empty():
                if not self.URLfrontier.empty():
                    while not self.URLfrontier.empty():
                        self.queue.put(self.URLfrontier.get())
                        self.URLfrontier.task_done()
                        
            while not self.queue.empty():
                self.crawlNextPage()
                
            print("Finished crawl at level " + str(self.currentCrawlDepth))
            self.currentCrawlDepth += 1
            
    def crawl(self, params):
        if "depth" in params:
            self.targetCrawlDepth = params["depth"]
        if "count" in params:
            self.targetCrawlCount = params["count"]
        if "domain" in params:
            self.targetDomain = params["domain"]
    
        while not self.queue.empty() or not self.URLfrontier.empty():
            self.crawlNextLevel()

class Crawler1:
    def __init__(self, seedURL):
        self.queue = Queue()
        self.queue.put(seedURL)
        
        self.URLfrontier = Queue()
        
        self.currentCrawlCount = 0
        self.currentCrawlDepth = 0
        
        self.targetCrawlCount = -1
        self.targetCrawlDepth = -1
        self.targetDomain = ""
        
        self.seen = {}
        
    def download(self, url, output_path="./temp"):
        try:
            pageHTML = urlopen(url)
        except:# HTTPError as e:
            #print(e)
            return None
        
        if pageHTML is None:
            print("warning: URL '" + url + "' not found")
            return None
        else:
            if not isdir(output_path):
                makedirs(output_path)
                
        
            pageObj = BeautifulSoup(pageHTML.read(),"html.parser")
            pageHTML.close()
            
            title = str(pageObj.title)
            title = re.sub('<[^>]*>', '', title)
            #print(title)
            
            text = str(pageObj.html)
            
            #path = str(url[8:])
            #print(path)
            filename = str(title[:150] + ".htm")
            badchars = ["<", ">", ":", "/", "\\", "|", "?", "*", "\n", "\t", "\r", "\"", "%"]
            filename = "".join([c for c in filename if c not in badchars])
            
            
            outputFile = open(join(output_path, filename), 'w', encoding='utf8')
            outputFile.write(text)
            outputFile.close()
            
            return pageObj
        
    def crawlNextPage(self):
        if not (self.currentCrawlCount < self.targetCrawlCount) and self.targetCrawlCount != -1:
            self.queue = Queue()
            self.URLfrontier = Queue()
            return
        else:
            url = self.queue.get()
                    
            pageObj = self.download(url)
            
            if pageObj is not None:
                self.currentCrawlCount += 1
            
                print("    Processing page #" + str(self.currentCrawlCount) + " at depth " + str(self.currentCrawlDepth) + " with URL '" + url[:100] + "'")
            
                pageLinks = pageObj.find_all('a')
                pageURLs = []
                if pageLinks is not None:
                    '''
                    for link in pageLinks:
                        if link.has_attr("href"):
                            pageURLs.append(urljoin(url, link["href"]))
                            
                        else:
                            print("========================PROBLEM HERE========================")
                            print(url)
                            try:
                                print(link)
                            except:
                                print("<unicode link>")
                    '''        
                    pageURLs = [urljoin(url, x["href"]) for x in pageLinks if x.has_attr("href")]
                
                for link in pageURLs:
                    #correct_format = link.endswith(("html", "htm", "txt", "/"))
                    correct_format = not link.endswith(("pdf", "jpg", "png", "gif"))
                    correct_domain = self.targetDomain in link
                    link_not_seen = link not in self.seen
                    if correct_format and link_not_seen and correct_domain:
                        self.URLfrontier.put(link)
                        self.seen[link] = 1
                
                self.queue.task_done()
        
    def crawlNextLevel(self):
        
        if not (self.currentCrawlDepth <= self.targetCrawlDepth) and self.targetCrawlDepth != -1:
            self.queue = Queue()
            self.URLfrontier = Queue()
            return
        else:
            if self.queue.empty():
                if not self.URLfrontier.empty():
                    while not self.URLfrontier.empty():
                        self.queue.put(self.URLfrontier.get())
                        self.URLfrontier.task_done()
                        
            while not self.queue.empty():
                self.crawlNextPage()
                
            print("Finished crawl at level " + str(self.currentCrawlDepth))
            self.currentCrawlDepth += 1
            
    def crawl(self, params):
        if "depth" in params:
            self.targetCrawlDepth = params["depth"]
        if "count" in params:
            self.targetCrawlCount = params["count"]
        if "domain" in params:
            self.targetDomain = params["domain"]
    
        while not self.queue.empty() or not self.URLfrontier.empty():
            self.crawlNextLevel()
                    
        
if __name__ == "__main__":
    auto = True
    if auto:
        domain = "http://www.eecs.ku.edu"#input("What seed URL would you like to use? ")
        domain_limit = "eecs.ku.edu"#input("What domain should the crawl be limited to? ")
        depth = 2#int(input("How deep would you like to crawl? "))
        count = 500
    else:
        domain = input("What seed URL would you like to use? ")
        domain_limit = input("What domain should the crawl be limited to? ")
        depth = int(input("How deep would you like to crawl? "))
        count = int(input("How many total pages would you like to crawl (0 = unlimited)?"))
    c = Crawler(domain)
    
    if count > 0:
        c.crawl({"count": count, "depth": depth, "domain": domain_limit})
    else:
        c.crawl({"depth": depth, "domain": domain_limit})